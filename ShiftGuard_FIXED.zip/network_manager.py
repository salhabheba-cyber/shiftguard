import socket
import os
import subprocess
import re
from pathlib import Path
import platform

class NetworkManager:
    def __init__(self):
        self.os_type = platform.system()
        self.hosts_path = self._get_hosts_path()
    
    def _get_hosts_path(self):
        """Get hosts file path based on OS"""
        if self.os_type == "Windows":
            return r"C:\Windows\System32\drivers\etc\hosts"
        else:
            return "/etc/hosts"
    
    # ─────────────────────────────────────────────────────────────────────────
    # NETWORK SCANNING
    # ─────────────────────────────────────────────────────────────────────────
    
    def get_network_info(self):
        """Get basic network info"""
        try:
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            
            # Get router IP (gateway)
            router_ip = self._get_gateway()
            
            # Check if hosts blocking is active
            hosts_blocking_active = self._check_hosts_active()
            
            # Count devices on network
            device_count = self._estimate_device_count()
            
            return {
                "status": "success",
                "hostname": hostname,
                "local_ip": local_ip,
                "router_ip": router_ip,
                "hosts_blocking": hosts_blocking_active,
                "estimated_devices": device_count
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}
    
    def _get_gateway(self):
        """Get default gateway IP"""
        try:
            if self.os_type == "Windows":
                # Windows: use ipconfig
                output = subprocess.check_output(['ipconfig'], text=True, timeout=5)
                match = re.search(r'Default Gateway\s*\.\s*:\s*([\d\.]+)', output, re.IGNORECASE)
                if match:
                    return match.group(1).strip()
            else:
                # Linux: use ip route
                output = subprocess.check_output(['ip', 'route'], text=True, timeout=5)
                match = re.search(r'default via ([\d\.]+)', output)
                if match:
                    return match.group(1).strip()
        except:
            pass
        return "Unknown"
    
    def _check_hosts_active(self):
        """Check if hosts file has blocking entries"""
        try:
            with open(self.hosts_path, 'r') as f:
                content = f.read()
                # Look for blocked domain patterns
                blocked_count = len([line for line in content.split('\n') 
                                   if line.strip() and not line.strip().startswith('#') 
                                   and '127.0.0.1' in line])
                return blocked_count > 0
        except:
            return False
    
    def _estimate_device_count(self):
        """Estimate devices on network using ARP (Windows-safe)"""
        try:
            if self.os_type == "Windows":
                # Use arp -a which doesn't require admin
                output = subprocess.check_output(['arp', '-a'], text=True, timeout=10)
                # Count dynamic entries (exclude static entries)
                lines = [line for line in output.split('\n') 
                        if 'dynamic' in line.lower()]
                return len(lines)
            else:
                # Linux: use arp-scan if available
                try:
                    output = subprocess.check_output(['arp-scan', '--localnet'], 
                                                   text=True, timeout=10, 
                                                   stderr=subprocess.DEVNULL)
                    return len([l for l in output.split('\n') if '\t' in l])
                except:
                    # Fallback to ip command
                    output = subprocess.check_output(['ip', 'neigh'], text=True, timeout=10)
                    return len([l for l in output.split('\n') if 'REACHABLE' in l])
        except Exception as e:
            print(f"[NET] Device count estimation failed: {e}")
            return 0
    
    def scan_network(self):
        """
        Scan network for connected devices.
        Windows-friendly: uses ARP table (no scapy, no promiscuous mode required)
        """
        try:
            devices = []
            
            if self.os_type == "Windows":
                # Use Windows arp command - requires only standard user
                output = subprocess.check_output(['arp', '-a'], text=True, timeout=10)
                
                for line in output.split('\n'):
                    line = line.strip()
                    if not line or line.startswith('Interface') or 'dynamic' not in line.lower():
                        continue
                    
                    # Parse: "192.168.1.100        00-1a-2b-3c-4d-5e     dynamic"
                    parts = line.split()
                    if len(parts) >= 2:
                        ip = parts[0]
                        mac = parts[1] if len(parts) > 1 else "Unknown"
                        
                        # Try to get hostname
                        hostname = self._try_reverse_dns(ip)
                        
                        devices.append({
                            "ip": ip,
                            "mac": mac,
                            "hostname": hostname,
                            "status": "online"
                        })
            
            else:  # Linux/Mac
                # Use arp or ip command
                try:
                    output = subprocess.check_output(['ip', 'neigh'], text=True, timeout=10)
                    for line in output.split('\n'):
                        parts = line.split()
                        if len(parts) >= 5 and 'REACHABLE' in line:
                            ip = parts[0]
                            mac = parts[4] if len(parts) > 4 else "Unknown"
                            hostname = self._try_reverse_dns(ip)
                            devices.append({
                                "ip": ip,
                                "mac": mac,
                                "hostname": hostname,
                                "status": "online"
                            })
                except:
                    # Fallback
                    return {"status": "error", 
                           "message": "Network scan not available. Run with sudo or install arp-scan."}
            
            return {
                "status": "success",
                "device_count": len(devices),
                "devices": devices[:50]  # Limit to 50 devices
            }
        
        except subprocess.TimeoutExpired:
            return {"status": "error", "message": "Network scan timed out. Check network connectivity."}
        except Exception as e:
            return {"status": "error", "message": f"Scan failed: {str(e)}"}
    
    def _try_reverse_dns(self, ip):
        """Try to resolve IP to hostname"""
        try:
            hostname = socket.gethostbyaddr(ip)[0]
            return hostname
        except:
            return "Unknown"
    
    # ─────────────────────────────────────────────────────────────────────────
    # HOSTS FILE MANAGEMENT
    # ─────────────────────────────────────────────────────────────────────────
    
    def get_blocked_sites(self):
        """Read currently blocked sites from hosts file"""
        blocked = []
        try:
            with open(self.hosts_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        parts = line.split()
                        if len(parts) >= 2 and parts[0] == '127.0.0.1':
                            blocked.append({
                                'ip': parts[0],
                                'domain': parts[1],
                                'status': 'blocked'
                            })
        except Exception as e:
            print(f"[NET] Error reading hosts file: {e}")
        
        return blocked
    
    def add_blocked_site(self, domain):
        """Add domain to hosts file block list"""
        try:
            entry = f"127.0.0.1 {domain}\n"
            
            # Check if already exists
            with open(self.hosts_path, 'r') as f:
                if domain in f.read():
                    return {"status": "error", "message": f"{domain} already blocked"}
            
            # Append to hosts file
            with open(self.hosts_path, 'a') as f:
                f.write(entry)
            
            # Flush DNS cache
            self._flush_dns()
            
            return {"status": "success", "message": f"Blocked {domain}"}
        except PermissionError:
            return {"status": "error", "message": "Admin/root privileges required"}
        except Exception as e:
            return {"status": "error", "message": str(e)}
    
    def remove_blocked_site(self, domain):
        """Remove domain from hosts file block list"""
        try:
            with open(self.hosts_path, 'r') as f:
                lines = f.readlines()
            
            # Filter out the blocked domain
            new_lines = [l for l in lines if domain not in l or l.startswith('#')]
            
            with open(self.hosts_path, 'w') as f:
                f.writelines(new_lines)
            
            self._flush_dns()
            return {"status": "success", "message": f"Unblocked {domain}"}
        except PermissionError:
            return {"status": "error", "message": "Admin/root privileges required"}
        except Exception as e:
            return {"status": "error", "message": str(e)}
    
    def _flush_dns(self):
        """Flush DNS cache"""
        try:
            if self.os_type == "Windows":
                subprocess.run(['ipconfig', '/flushdns'], capture_output=True, timeout=5)
            else:
                subprocess.run(['sudo', 'systemctl', 'restart', 'systemd-resolved'], 
                             capture_output=True, timeout=5)
        except:
            pass

# ─────────────────────────────────────────────────────────────────────────────
# TEST LOCALLY
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    nm = NetworkManager()
    
    print("\n[TEST] Network Info:")
    info = nm.get_network_info()
    for k, v in info.items():
        print(f"  {k}: {v}")
    
    print("\n[TEST] Network Scan:")
    scan = nm.scan_network()
    print(f"  Status: {scan.get('status')}")
    print(f"  Message: {scan.get('message', 'N/A')}")
    if scan.get('status') == 'success':
        print(f"  Found devices: {scan.get('device_count')}")
        for device in scan.get('devices', [])[:5]:
            print(f"    - {device['ip']} ({device.get('hostname', 'Unknown')})")
    
    print("\n[TEST] Blocked Sites:")
    blocked = nm.get_blocked_sites()
    print(f"  Currently blocked: {len(blocked)} domains")

